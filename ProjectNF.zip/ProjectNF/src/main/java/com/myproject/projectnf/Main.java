
package com.myproject.projectnf;


public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new ViewNotaFiscal().setVisible(true);
        });
    }
}

