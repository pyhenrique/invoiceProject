package com.myproject.projectnf;

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;


public class ClienteDAO {
    private Connection conexao;

    public ClienteDAO() {
        this.conexao = Conexao.conectar();
    }

    // INSERIR CLIENTE
    public boolean inserir(Cliente cliente) {
        String sql = "INSERT INTO a01_cliente (nome, cpf, endereco, telefone, email) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getCpfCnpj());
            stmt.setString(3, cliente.getEndereco());
            stmt.setString(4, cliente.getTelefone());
            stmt.setString(5, cliente.getEmail());
            
            stmt.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            if (e.getSQLState().equals("23505")) { // Violação de chave única (CPF duplicado)
                JOptionPane.showMessageDialog(null, "Erro: CPF/CNPJ já cadastrado!", "Erro", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar cliente:\n" + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
            return false;
        }
    }

    // ATUALIZAR CLIENTE
    public boolean atualizar(Cliente cliente) {
        String sql = "UPDATE a01_cliente SET nome=?, endereco=?, telefone=?, email=? WHERE cpf=?";
        
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getEndereco());
            stmt.setString(3, cliente.getTelefone());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, cliente.getCpfCnpj());
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                JOptionPane.showMessageDialog(null, "Cliente não encontrado para atualização!", "Aviso", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar cliente:\n" + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // REMOVER CLIENTE
    public boolean remover(String cpfCnpj) {
        String sql = "DELETE FROM a01_cliente WHERE cpf=?";
        
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, cpfCnpj);
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                JOptionPane.showMessageDialog(null, "Cliente não encontrado para remoção!", "Aviso", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            return true;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao remover cliente:\n" + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    // CONSULTAR CLIENTE
    public Cliente consultar(String cpfCnpj) {
        String sql = "SELECT * FROM a01_cliente WHERE cpf=?";
        Cliente cliente = null;
        
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, cpfCnpj);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                cliente = new Cliente();
                cliente.setNome(rs.getString("nome"));
                cliente.setCpfCnpj(rs.getString("cpf"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setEmail(rs.getString("email"));
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar cliente:\n" + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
        
        return cliente;
    }

    // FECHAR CONEXÃO (opcional - pode ser chamado quando a aplicação encerrar)
    @SuppressWarnings("try")
    public void fecharConexao() {
        try {
            if (conexao != null && !conexao.isClosed()) {
                conexao.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexão:\n" + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}