package com.myproject.projectnf;

public class Cliente {
    private int id;
    private String nome;
    private String cpfCnpj;
    private String endereco;
    private String telefone;
    private String email;
    private String dataCadastro;
    private double credito;

    // Getters e Setters
}
