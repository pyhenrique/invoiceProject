package com.myproject.projectnf;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NotaFiscalDAO {

    public List<NotaFiscal> listarNotas() {
        List<NotaFiscal> lista = new ArrayList<>();
        String sql = "SELECT * FROM a04_pedido";
        try (Connection con = Conexao.conectar();
             PreparedStatement stmt = con.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                NotaFiscal nf = new NotaFiscal();
                nf.setId(rs.getInt("A04_id_pedido"));
                nf.setTotal(rs.getDouble("A04_valor_total"));
                // depois carrega cliente e itens
                lista.add(nf);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
