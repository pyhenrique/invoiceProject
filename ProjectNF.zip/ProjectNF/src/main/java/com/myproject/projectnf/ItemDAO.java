/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myproject.projectnf;

import com.myproject.projectnf.NotaFiscal.ItemNota;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    public void inserir(ItemNota item, int codigoPedido) {
        String sql = "INSERT INTO a03_item (a04_codigo, a02_codigo, a03_quantidade, a03_preco_unitario) VALUES (?, ?, ?, ?)";
        try (Connection con = Conexao.conectar();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, codigoPedido);
            stmt.setInt(2, item.getProduto().getId());
            stmt.setInt(3, item.getQuantidade());
            stmt.setDouble(4, item.getPrecoUnitario());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void remover(int idItem) {
        String sql = "DELETE FROM a03_item WHERE a03_codigo = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, idItem);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<ItemNota> listarPorPedido(int codigoPedido) {
        List<ItemNota> lista = new ArrayList<>();
        String sql = "SELECT * FROM a03_item WHERE a04_codigo = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement stmt = con.prepareStatement(sql)) {
            stmt.setInt(1, codigoPedido);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ItemNota item = new ItemNota();
                    Produto p = new Produto();
                    p.setId(rs.getInt("a02_codigo"));
                    item.setProduto(p);
                    item.setQuantidade(rs.getInt("a03_quantidade"));
                    item.setPrecoUnitario(rs.getDouble("a03_preco_unitario"));
                    lista.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

